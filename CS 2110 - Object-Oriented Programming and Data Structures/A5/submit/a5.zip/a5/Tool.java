/**  DO NOT MODIFY THIS CLASS IN ANY WAY.
 * 
 * An enumeration of all available tools. */
public enum Tool {
	PENCIL, ERASER, COLOR_PICKER, AIRBRUSH, LINE, CIRCLE
}
