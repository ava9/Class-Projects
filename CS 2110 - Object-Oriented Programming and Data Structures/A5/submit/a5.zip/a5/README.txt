Aditya Agashe (ava9)
Shankar Athinarayanan (sa625)

No issues with the code.

Discussed the homework with:
1) Peter Mikelis